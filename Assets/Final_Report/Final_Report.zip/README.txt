ABOUT THE PROJECT
This is a CS course project that implements a basic snakes and ladders game with some additional features.

TO RUN THE PROGRAM
Run the following commands in order to run the program

    gcc Main.c Headers/position.c
    a.exe

ADDITIONAL HEADER FILES USED (OTHER THAN stdio.h and stdlib.h)
conio.h to end the program with keypress
time.h to add delays here and there
A custom header file position.h to randomize the positions of snakes and ladders on each execution.