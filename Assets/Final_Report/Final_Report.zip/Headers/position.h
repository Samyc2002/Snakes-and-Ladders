#ifndef POSITION
#define POSITION

#include <stdio.h>
#include <stdlib.h>

int search(int n, int arr[], int len);
void position();

#endif